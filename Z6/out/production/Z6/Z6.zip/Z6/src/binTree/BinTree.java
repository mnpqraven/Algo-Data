package binTree;

import java.util.ArrayList;
import java.util.List;

/**
 * This class implements a binary tree
 *
 * @param <T>
 */
public class BinTree<T> {

    protected BinTree<T> left, right;
    protected T key;

    /**
     * creates a new instance
     * @param l the left subtree
     * @param k the key of the tree node
     * @param r the right subtree
     */
    public BinTree(BinTree<T> l, T k, BinTree<T> r) {
        this.left = l;
        this.key = k;
        this.right = r;
    }

    /**
     * returns the left subtree
     */
    public BinTree<T> getLeft() {
        return left;
    }

    /**
     * returns the left subtree
     */
    public BinTree<T> getRight() {
        return right;
    }

    /**
     * returns the key
     */
    public T getKey() {
        return key;
    }

    /**
     * checks if the tree is empty
     * @return true, if tree is empty, else false
     */
    public boolean isEmpty() {
        return ((left == null) && (right == null) && (key == null));
    }

    /**
     * returns the size of the list
     * @return the size of the list
     */
    int size(BinTree<T> tail) {
        return ((left == tail) ? 0 : left.size(tail)) + 1
                + ((right == tail) ? 0 : right.size(tail));
    }

    /**
     * @return the Post-Order representation of this tree
     */
    public List<T> postOrder() {
        if (this.isEmpty()) return null;
        ArrayList<T> l1 = new ArrayList<T>();
        if(this.left !=null) l1.addAll(this.left.postOrder());
        if(this.right !=null) l1.addAll(this.right.postOrder());
        l1.add(this.getKey());
        return l1;
    }

    /**
     * @return the Pre-Order representation of this tree
     */
    public List<T> preOrder() {
        if (this.isEmpty()) return null;
        ArrayList<T> l1 = new ArrayList<T>();
        l1.add(this.getKey());
        if(this.left !=null) l1.addAll(this.left.preOrder());
        if(this.right !=null) l1.addAll(this.right.preOrder());
        return l1;
    }

    public static void main(String[] args) {
        //TODO
        BinTree<Character> t1 = new BinTree<>(
                new BinTree<>(
                        new BinTree<>(
                                new BinTree<>(null, 'e', null),
                                'f',
                                null),
                        'a',
                        new BinTree<>(null,'c',null)),
                'g',
                 new BinTree<>(
                        new BinTree<>(
                                null,
                                'h',
                                new BinTree<>(null, 'B', null)),
                        'd',
                        null)
        );
        System.out.println(t1.postOrder());
        System.out.println(t1.preOrder());
    }

}
