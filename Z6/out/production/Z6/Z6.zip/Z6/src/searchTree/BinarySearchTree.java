package searchTree;

/**
 * Represents a binary search tree
 *
 * @param <K> the element type
 */
public class BinarySearchTree<K extends Comparable<K>> {
	
	/**
	 * Represents an inner node of the enclosing search tree
	 */
	private class Node {
		/** The value of this node */
		private K value;
		/** The left child of this node */
		private Node left;
		/** The right child of this node */
		private Node right;
		
		/**
		 * Constructs a new leaf node with the given value
		 * @param value the value
		 */
		public Node(K value) {
			this.value = value;
		}

		/**
		 * @return the height of the sub-tree rooted in this node
		 */
		int height() {
			int hl = left  != null ? left.height() : 0;
			int hr = right != null ? right.height() : 0;
			return 1 + Math.max(hl, hr);
		}
	}
	
	/** The tree root */
	private Node root;

	/** Which remove was used the last time*/
	private boolean lastRemoveWasPred = false;
	
	/**
	 * @return true if this tree is empty, false otherwise
	 */
	public boolean isEmpty() {
		return root == null;
	}
	
	/**
	 * @return the height of this tree
	 */
	public int height() {
		return root == null ? 0 : root.height();
	}
	
	/** 
	 * Adds the given value to this tree
	 * @param value
	 */
	public void add(K value ) {
		root = internalAdd(root, value);
	}
	
	/**
	 * Checks if the given value is contained in this tree
	 * @param value
	 * @return true if the value is contained, false otherwise
	 */
	public boolean contains(K value) {
		return internalContains(root, value);
	}
	
	/**
	 * Removes the given value from this tree
	 * @param value the value to remove;
	 */
	public void remove(K value) {
		root = internalRemove(root, value);
	}
	
	/**
	 * Adds the given value to the sub-tree rooted in n
	 * @param n the root of the sub-tree
	 * @param value the value to add
	 * @return the (potentially) modified node
	 */
	private Node internalAdd( Node n, K value ) {
		if ( n == null )
			return new Node(value);
		
		int cmp = value.compareTo(n.value);
		if ( cmp < 0 )
			n.left = internalAdd(n.left, value);
		else if ( cmp > 0 )
			n.right = internalAdd(n.right, value);
		
		return n;
	}
	
	/**
	 * Checks if the given value is contained in the sub-tree rooted in n
	 * @param n the root of the sub-tree
	 * @param value the value to check for
	 * @return true if the value is contained, false otherwise 
	 */
	private boolean internalContains( Node n, K value ) {
		if ( n == null )
			return false;
		
		int cmp = value.compareTo(n.value);
		if ( cmp < 0 )
			return internalContains(n.left, value);
		else if ( cmp > 0 )
			return internalContains(n.right, value);
		return true;
	}
	
	
	/**
	 * Removes the given value  fron the sub-tree rooted in n
	 * @param n the root of the sub-tree
	 * @param value the value to remove
	 * @return the (potentially) modyfied node
	 */
	private Node internalRemove( Node n, K value  ) {
		if ( n == null )
			return null;
		
		int cmp = value.compareTo(n.value);
		// left recursive
		if ( cmp < 0 )
			n.left = internalRemove(n.left, value);
		// right recursive
		else if ( cmp > 0 )
			n.right = internalRemove(n.right, value);
		// left sub-tree empty
		else if ( n.left == null )
			return n.right;
		// right sub-tree empty
		else if ( n.right == null )
			return n.left;
		// has two children
		else {
			// TODO 
			removeSymSucc(n);
		}
		return n;
	}
	
	/**
	 * Removes the value of node n by replacing it with its symmetric successor
	 * @param n the node holding the value to remove
	 */
	private void removeSymSucc( Node n ) {
		Node p = n;
		if (p.right.left != null) {
			p = p.right; 
			while (p.left.left != null)
				p = p.left;
		
			n.value = p.left.value;
			p.left = p.left.right;
		} 
		else {
			n.value = n.right.value;
			n.right = n.right.right;
		}
	}
	
	/**
	 * Removes the value of node n by replacing it with its symmetric predecessor
	 * @param n the node holding the value to remove
	 */
	private void removeSymPred( Node n ) {
		Node p = n;
		if (p.left.right != null) {
			p = p.left;
			while (p.right.right != null)
				p = p.right;

			n.value = p.right.value;
			p.right = p.right.right;
		}
		else {
			n.value = n.left.value;
			n.left = n.left.left;
		}
	}

	// Strategie zum Löschen 1:
	// Beschreibung in PDF
	private void removeSymDynamic( Node n ) {
		int leftHeight = n.left.height();
		int rightHeight = n.right.height();
		if(leftHeight > rightHeight)
			removeSymPred( n );
		else
			removeSymSucc( n );
	}

	// Strategie zum Löschen 2:
	private void removeSymAlternately( Node n ) {
		if(lastRemoveWasPred)
			removeSymSucc( n );
		else
			removeSymPred( n );
		lastRemoveWasPred = !lastRemoveWasPred;
	}
	
	public String toString() {
		String values = toStringInt(root);
		// Remove leading ','
		if ( !values.isEmpty() )
			values = values.substring(1);
		return "BinarySearchTree (" + values + ")";
	}
	
	private String toStringInt(Node n) {
		if ( n == null )
			return "";
		else
			return toStringInt(n.left) + "," + n.value + toStringInt(n.right);
	}
	
	public static void main(String[] args) {
		BinarySearchTree<Integer> tree = new BinarySearchTree<>();
		
		tree.add(4);
		tree.add(2);
		tree.add(1);
		tree.add(3);
		tree.add(6);
		tree.add(5);
		tree.add(7);

		System.out.println(tree);
		System.out.println(tree.height());
	}
}
